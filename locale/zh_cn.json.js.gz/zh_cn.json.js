(function () {
const dict = {
  "app.name": "静格设计",
  "email.subject.register": "注册验证码",
  "email.error.exists": "该邮箱已经被注册",
  "error.unauthorized": "没有权限进行此操作",
  "error.need_login": "请先登陆"
};
window.__AssetLoader.Asset.locale = dict;
})();
