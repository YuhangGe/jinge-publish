(function () {
const dict = {
  "app.name": "JINGE DESIGN",
  "error.unauthorized": "没有权限进行此操作"
};
window.__AssetLoader.Asset.locale = dict;
})();
